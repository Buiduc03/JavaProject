package Project1;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class BookManager {
    private final ArrayList<Book> books;

    public BookManager() {
        this.books = new ArrayList<>();
    }

    public ArrayList<Book> getBooks() {
        return books;
    }

    public void loadFromFile() throws IOException {
        BufferedReader myReader = new BufferedReader(new FileReader("books.txt"));
        String myLine = myReader.readLine();
        System.out.println("Loading books...");
        while (myLine != null && myLine.length() > 0) {
            String idSt = myLine.substring(0, 5).trim();
            int id = Integer.parseInt(idSt);
            String name = myLine.substring(5, 50).trim();
            String priceSt = myLine.substring(50).trim();
            double price = Double.parseDouble(priceSt);
            books.add(new Book(id, name, price));
            myLine = myReader.readLine();
        }
        myReader.close();
    }

    public void printBook(ArrayList<Book> books) {
        if (books.size() == 0) {
            System.out.println("(empty)");
        } else {
            System.out.printf("%-5s %-45s %-10s\n", "ID", "Name", "Price");
            for (Book book : books) {
                System.out.println(book.toString());
            }
        }
    }

    public boolean add(Book book) {
        for (Book book1 : books) {
            if (book1.getId() == book.getId()) {
                return false;
            }
        }
            books.add(book);
            return true;
    }
    public Book getBookById(int id) {
        for (Book book1 : books) {
            if (book1.getId() == id)
                return book1;
        }
        return null;
    }
    public void delete(Book book) {
        if (book != null) {
            books.remove(book);
        }
    }
    public void sortDescByPrice() {
        for (int i = 0; i < books.size(); i++)
            for (int j = 0; j < books.size() - i - 1; j++)
                if (books.get(j).getPrice() < books.get(j + 1).getPrice()) {
                    Book k = books.get(j);
                    books.set(j, books.get(j + 1));
                    books.set(j + 1, k);
                }
    }
    public ArrayList<Book> searchByName(String keyword) {
        ArrayList<Book> fitInWord = new ArrayList<>();
        for (Book book2 : books) {
            if (book2.getName().toLowerCase().contains(keyword.toLowerCase())) {
                fitInWord.add(book2);
            }
        }
        return fitInWord;
    }
    public void saveToFile() throws IOException {
        BufferedWriter myWriter = new BufferedWriter(new FileWriter("books.txt"));
        for (Book book3 : books) {
            myWriter.append(book3.toString()).append("\n");
        }
        myWriter.close();
    }
}

