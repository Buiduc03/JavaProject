package Project1;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        File file = new File("books.txt");
        file.createNewFile();
        BookManager myBookManager = new BookManager();
        int myOption = 100;
        Scanner sc = new Scanner(System.in);
        myBookManager.loadFromFile();
        while (myOption != 0) {
            System.out.print("-----------------------------------\n" +
                    "1. list all books\n" +
                    "2. add a new book\n" +
                    "3. edit book\n" +
                    "4. delete a book\n" +
                    "5. search books by name\n" +
                    "6. sort books descending by price\n" +
                    "0. save & exit\n" +
                    "-----------------------------------\n" +
                    "Your option: ");
            myOption = sc.nextInt();
            sc.nextLine();
            switch (myOption) {
                case 1:
                    myBookManager.printBook(myBookManager.getBooks());
                    break;
                case 2:
                    addBook(sc, myBookManager);
                    break;
                case 3:
                    editBook(sc, myBookManager);
                    break;
                case 4:
                    deleteBook(sc, myBookManager);
                    break;
                case 5:
                    searchBook(sc, myBookManager);
                    break;
                case 6:
                    sortBook(sc, myBookManager);
                    break;
                case 0:
                    saveAndExit(sc, myBookManager);
                default:
                    System.out.println("Invalid option!");
            }
        }
        saveAndExit(sc, myBookManager);
    }
    private static void addBook(Scanner sc, BookManager bookManager) {
        System.out.println("Enter book id: ");
        int id = sc.nextInt();
        sc.nextLine();
        System.out.println("Enter book name: ");
        String name = sc.nextLine();
        System.out.println("Enter book price: ");
        double price = sc.nextDouble();
        sc.nextLine();
        Book newBook = new Book(id, name, price);
        if (bookManager.add(newBook)) {
            System.out.println("Added successfully.");
        }
        else {
            System.out.println("Duplicated ID!");
        }
    }
    private static void editBook(Scanner sc, BookManager bookManager) {
        System.out.println("Enter book id: ");
        int id = sc.nextInt();
        sc.nextLine();
        Book bookFromFile = bookManager.getBookById(id);
        if (bookFromFile == null) {
            System.out.println("Invalid ID!");
            return;
        }
        System.out.println("Enter book name: ");
        String name = sc.nextLine();
        System.out.println("Enter book price: ");
        double price = sc.nextDouble();
        sc.nextLine();
        bookFromFile.setName(name);
        bookFromFile.setPrice(price);
        System.out.println("Updated successfully.");
    }
    private static void deleteBook(Scanner sc, BookManager bookManager) {
        System.out.println("Enter book id: ");
        int id = sc.nextInt();
        sc.nextLine();
        int initialSize = bookManager.getBooks().size();
        bookManager.delete(bookManager.getBookById(id));
        if (initialSize == bookManager.getBooks().size()) {
            System.out.println("Invalid ID!");
        }
        else {
            System.out.println("Deleted successfully");
        }
    }
    private static void searchBook(Scanner sc, BookManager bookManager) {
        System.out.println("Enter your keyword");
        String newKeyWord = sc.nextLine();
        ArrayList<Book> search = bookManager.searchByName(newKeyWord);
        bookManager.printBook(search);
     }
     private static void sortBook(Scanner sc, BookManager bookManager) {
        bookManager.sortDescByPrice();
         System.out.println("After sorting: ");
         bookManager.printBook(bookManager.getBooks());
     }
     private static void saveAndExit(Scanner sc, BookManager bookManager) throws IOException {
        bookManager.saveToFile();
         System.out.println("Saving to file...\n" + "Bye!");
     }
}
